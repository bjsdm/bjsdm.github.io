package com.example.testblockcanary

import android.os.*
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.github.moduth.blockcanary.internal.BlockInfo

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initDelayHandler()
        initPrinter()
    }

    //使用 printerStart 进行判断是方法执行前还是执行后调用 println
    private var printerStart = true

    //记录方法执行前的时间
    private var printerStartTime = 0L

    //方法执行时间超过该值才输出
    private val minTime = 1000L

    private fun initPrinter() {
        Looper.getMainLooper().setMessageLogging {
            if (printerStart) {
                printerStart = false
                printerStartTime = System.currentTimeMillis();
                delayHandler.removeCallbacks(runnable)
                //延迟minTime * 0.8发送，用于记录阻塞时的栈信息
                delayHandler.postDelayed(runnable, (minTime * 0.8).toLong())
            } else {
                printerStart = true
                delayHandler.removeCallbacks(runnable)
                (System.currentTimeMillis() - printerStartTime).let {
                    if (it >= minTime) {
                        Log.i("Printer", "方法运行的总时长：${it}")
                        Log.i("Printer", "StackTrace：${stringBuilder.toString()}")
                    }
                }
            }
        }
    }

    private lateinit var delayHandler: Handler
    private fun initDelayHandler() {
        //让Handler的消息在子线程中运行
        val handlerThread = HandlerThread("DelayThread")
        handlerThread.start()

        delayHandler = Handler(handlerThread.looper)
    }

    private val stringBuilder = StringBuilder()
    private val runnable = Runnable {
        //获取栈信息进行记录
        for (stackTraceElement in Looper.getMainLooper().getThread().getStackTrace()) {
            stringBuilder
                .append(stackTraceElement.toString())
                .append(BlockInfo.SEPARATOR)
        }

    }


    fun clickView(view: View) {
        SystemClock.sleep(2000)
    }
}