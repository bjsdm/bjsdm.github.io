package com.example.testblockcanary

import android.app.Application
import com.github.moduth.blockcanary.BlockCanary
import com.github.moduth.blockcanary.BlockCanaryContext

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        BlockCanary.install(this, BlockCanaryContext()).start()
    }
}